"use client";

import { useState, useEffect } from "react";
import { ethers } from "ethers";
import { GlowButton } from "./ui/glow-button";

interface NFTMintingProps {
  provider: ethers.providers.Web3Provider | null;
  contractAddress: string;
  contractABI: any[];
}

export function NFTMinting({ provider, contractAddress, contractABI }: NFTMintingProps) {
  const [minting, setMinting] = useState(false);
  const [mintedTokenIds, setMintedTokenIds] = useState<number[]>([]);

  // Debugging logs
  useEffect(() => {
    console.log("Provider in NFTMinting:", provider);
    console.log("Minting state:", minting);
  }, [provider, minting]);

  const mintNFT = async () => {
    if (!provider) {
      alert("❌ Please connect your wallet first.");
      return;
    }

    try {
      setMinting(true);
      const signer = provider.getSigner();
      const contract = new ethers.Contract(contractAddress, contractABI, signer);

      // 🔹 Estimate gas limit to avoid failures
      const gasLimit = await contract.estimateGas.mint().catch(() => ethers.BigNumber.from("500000"));
      const tx = await contract.mint({ gasLimit });
      const receipt = await tx.wait();

      // 🔹 Find Transfer event to get the token ID
      const transferEvent = receipt.events?.find((event: any) => event.event === "Transfer");

      if (transferEvent) {
        const tokenId = transferEvent.args.tokenId.toNumber();
        setMintedTokenIds((prev) => [...prev, tokenId]);
      }
    } catch (error) {
      console.error("❌ Error minting NFT:", error);
      alert("⚠️ Failed to mint NFT. Please try again.");
    } finally {
      setMinting(false);
    }
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <GlowButton onClick={mintNFT} disabled={minting || !provider} variant="outline">
        {minting ? "Minting..." : "Mint NFT"}
      </GlowButton>

      {mintedTokenIds.length > 0 && (
        <div className="text-center animate-fade-in">
          <p className="text-green-400 font-semibold">✅ Minted Successfully!</p>
          {mintedTokenIds.map((tokenId) => (
            <p key={tokenId} className="text-sm text-gray-400">
              Token ID: {tokenId} -{" "}
              <a
                href={`https://edu-chain-testnet.blockscout.com/token/${contractAddress}?a=${tokenId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-400 underline"
              >
                View on Explorer
              </a>
            </p>
          ))}
        </div>
      )}
    </div>
  );
}

