"use client";

import { useState, useEffect } from "react";
import { ethers } from "ethers";
import { GlowButton } from "./ui/glow-button";

// ✅ EduChain Network Parameters
const EDUCHAIN_ID = 0xa045c; // Correct format (number instead of string)
const EDUCHAIN_PARAMS = {
  chainId: "0xA045C", // Must be a string in hexadecimal format
  chainName: "EduChain",
  nativeCurrency: {
    name: "EduCoin",
    symbol: "EDU",
    decimals: 18,
  },
  rpcUrls: ["https://open-campus-codex-sepolia.drpc.org"], // ✅ Ensure this is correct
  blockExplorerUrls: ["https://edu-chain-testnet.blockscout.com/"], // ✅ Ensure this is correct
};

interface WalletConnectProps {
  onConnect: (address: string, provider: ethers.providers.Web3Provider) => void;
}

export function WalletConnect({ onConnect }: WalletConnectProps) {
  const [address, setAddress] = useState<string>("");
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState<string>("");

  // ✅ Check & Switch Network
  const checkAndSwitchNetwork = async (provider: ethers.providers.Web3Provider) => {
    try {
      if (!window.ethereum) throw new Error("❌ MetaMask is not installed. Please install it.");

      const network = await provider.getNetwork();
      console.log("🔄 Current Network:", network);

      if (network.chainId !== EDUCHAIN_ID) {
        try {
          console.log("🔁 Switching to EduChain...");
          await window.ethereum.request({
            method: "wallet_switchEthereumChain",
            params: [{ chainId: "0xA045C" }],
          });
        } catch (switchError: any) {
          if (switchError.code === 4902) {
            console.log("⚠️ EduChain not found. Adding network...");
            await window.ethereum.request({
              method: "wallet_addEthereumChain",
              params: [EDUCHAIN_PARAMS],
            });
          } else {
            throw switchError;
          }
        }
      }
    } catch (error: any) {
      console.error("⚠️ Network Switch Error:", error);
      setError(error.message || "Failed to switch network. Please switch to EduChain manually.");
    }
  };

  // ✅ Auto-Detect Wallet Connection
  useEffect(() => {
    if (typeof window === "undefined" || !window.ethereum) {
      setError("❌ MetaMask is not installed. Please install it.");
      return;
    }

    const handleAccountsChanged = (accounts: string[]) => {
      if (accounts.length === 0) {
        setAddress("");
        setError("⚠️ Wallet disconnected. Please reconnect.");
      } else {
        setAddress(accounts[0]);
        setError("");
      }
    };

    const handleChainChanged = () => {
      window.location.reload();
    };

    window.ethereum.on("accountsChanged", handleAccountsChanged);
    window.ethereum.on("chainChanged", handleChainChanged);

    window.ethereum
      .request({ method: "eth_accounts" })
      .then((accounts: string[]) => {
        if (accounts.length > 0) {
          setAddress(accounts[0]);
        }
      })
      .catch((err: Error) => {
        console.error("⚠️ Failed to get accounts", err);
      });

    return () => {
      if (window.ethereum) {
        window.ethereum.removeListener("accountsChanged", handleAccountsChanged);
        window.ethereum.removeListener("chainChanged", handleChainChanged);
      }
    };
  }, []);

  // ✅ Connect Wallet Function
  const connectWallet = async () => {
    setError("");
    setConnecting(true);

    try {
      if (!window.ethereum) throw new Error("❌ MetaMask is not installed. Please install it.");

      const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
      const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });

      if (!accounts || accounts.length === 0) {
        throw new Error("❌ No accounts found. Please unlock MetaMask.");
      }

      await checkAndSwitchNetwork(provider);

      const signer = provider.getSigner();
      const userAddress = await signer.getAddress();

      setAddress(userAddress);
      onConnect(userAddress, provider);
    } catch (error: any) {
      console.error("❌ Wallet Connection Error:", error);
      setError(error.message || "Failed to connect. Try again.");
    } finally {
      setConnecting(false);
    }
  };

  return (
    <div className="flex flex-col items-center gap-4">
      {error && (
        <div className="w-full max-w-md px-4 py-3 rounded-lg bg-red-500/20 text-red-500 border border-red-500/50 text-center">
          {error}
        </div>
      )}

      {!address ? (
        <GlowButton onClick={connectWallet} loading={connecting} className="min-w-[200px]">
          {connecting ? "Connecting..." : "Connect Wallet"}
        </GlowButton>
      ) : (
        <div className="text-center">
          <p className="text-sm text-gray-400 mb-1">Connected Wallet</p>
          <p className="font-mono text-white">{`${address.slice(0, 6)}...${address.slice(-4)}`}</p>
        </div>
      )}
    </div>
  );
}

