"use client"

import { useState } from "react"
import { ethers } from "ethers"
import { GlowButton } from "./ui/glow-button"

interface NFTMetadata {
  name: string
  description: string
  image: string
}

interface MetadataDisplayProps {
  provider: ethers.providers.Web3Provider | null
  contractAddress: string
  contractABI: any[]
  tokenId: number | null
}

export function MetadataDisplay({ provider, contractAddress, contractABI, tokenId }: MetadataDisplayProps) {
  const [metadata, setMetadata] = useState<NFTMetadata | null>(null)
  const [loading, setLoading] = useState(false)

  const fetchMetadata = async () => {
    if (!provider || tokenId === null) {
      alert("Please mint an NFT first")
      return
    }

    try {
      setLoading(true)
      const contract = new ethers.Contract(contractAddress, contractABI, provider)

      const tokenURI = await contract.tokenURI(tokenId)
      const response = await fetch(tokenURI)
      const metadata = await response.json()

      setMetadata(metadata)
    } catch (error) {
      console.error("Error fetching metadata:", error)
      alert("Failed to fetch NFT metadata. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <GlowButton onClick={fetchMetadata} disabled={loading || !provider || tokenId === null} variant="outline">
        {loading ? "Loading..." : "View Metadata"}
      </GlowButton>

      {metadata && (
        <div className="max-w-md p-6 rounded-2xl border border-white/20 shadow-glow">
          <h3 className="text-xl font-bold mb-4 glow-text">{metadata.name}</h3>
          <p className="text-gray-400 mb-4">{metadata.description}</p>
          {metadata.image && (
            <img
              src={metadata.image || "/placeholder.svg"}
              alt={metadata.name}
              className="w-full rounded-lg shadow-glow"
            />
          )}
        </div>
      )}
    </div>
  )
}

