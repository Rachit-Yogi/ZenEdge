"use client";

import { useState } from "react";
import { ethers } from "ethers";
import Image from "next/image";
import { WalletConnect } from "@/components/wallet-connect";
import { NFTMinting } from "@/components/nft-minting";
import { MetadataDisplay } from "@/components/metadata-display";
import { GlowButton } from "@/components/ui/glow-button";

// Replace these with your actual contract details
const CONTRACT_ADDRESS = "0xBA4Ad6b21378b0669FbB9Cf74BD5eBD734f117dB";
const CONTRACT_ABI = [
  {
    inputs: [],
    name: "mint",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: "uint256",
        name: "tokenId",
        type: "uint256",
      },
      {
        indexed: false,
        internalType: "string",
        name: "name",
        type: "string",
      },
      {
        indexed: false,
        internalType: "string",
        name: "description",
        type: "string",
      },
      {
        indexed: false,
        internalType: "string",
        name: "imageURL",
        type: "string",
      },
    ],
    name: "Minted",
    type: "event",
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "tokenId",
        type: "uint256",
      },
    ],
    name: "getMetadata",
    outputs: [
      {
        internalType: "string",
        name: "",
        type: "string",
      },
      {
        internalType: "string",
        name: "",
        type: "string",
      },
      {
        internalType: "string",
        name: "",
        type: "string",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
];

export default function Home() {
  const [provider, setProvider] = useState<ethers.providers.Web3Provider | null>(null);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [mintedTokenId, setMintedTokenId] = useState<number | null>(null);

  const handleConnect = async (provider: ethers.providers.Web3Provider) => {
    setProvider(provider);
    const signer = provider.getSigner();
    const address = await signer.getAddress();
    setWalletAddress(address);
  };

  const handleMintSuccess = (tokenId: number) => {
    setMintedTokenId(tokenId);
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center">
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col items-center gap-6">
          {/* Logo */}
          <div className="relative w-64 h-24">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Zen%20EDGEgenerated_image.jpg-ZOpS9onYs9ZBCVfopzUMKCCRdYpMRL.jpeg"
              alt="ZenEdge Logo"
              fill
              className="object-contain animate-glow"
              priority
            />
          </div>

          <h1 className="text-5xl font-bold text-center glow-text animate-glow">AI-Generated Art NFT</h1>

          <p className="text-xl text-center text-white/80 glow-text max-w-2xl">
            Mint unique AI-generated artwork as NFTs on the Edu Chain
          </p>

          {/* Wallet Connection */}
          <WalletConnect onConnect={handleConnect} />

          {/* Display Wallet Address if Connected */}
          {walletAddress && (
            <p className="text-white/70 text-sm">
              <strong>Connected Wallet:</strong> {walletAddress.substring(0, 6)}...
              {walletAddress.substring(walletAddress.length - 4)}
            </p>
          )}

          {/* NFT Minting - Button Appears After Wallet Connects */}
          {provider && (
            <div className="w-full max-w-md flex flex-col items-center">
              <NFTMinting
                provider={provider}
                contractAddress={CONTRACT_ADDRESS}
                contractABI={CONTRACT_ABI}
                onMintSuccess={handleMintSuccess}
              />
            </div>
          )}

          {/* Metadata Display */}
          {provider && mintedTokenId !== null && (
            <div className="w-full max-w-md">
              <MetadataDisplay
                provider={provider}
                contractAddress={CONTRACT_ADDRESS}
                contractABI={CONTRACT_ABI}
                tokenId={mintedTokenId}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

